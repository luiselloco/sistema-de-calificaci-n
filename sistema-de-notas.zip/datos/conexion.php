<?php
	try {
		$cn = new PDO("mysql:host=127.0.0.1;dbname=bdescuela","root","");
	} catch (PDOException $ex) {
		print_r("Error: ". $ex->getMessage());
		//die($ex->getMessage());
		die();
	}
?>
