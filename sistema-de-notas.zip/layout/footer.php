<!-- Pie de la pagina web -->
	<footer class="d-flex flex-wrap justify-content-between align-items-center border-top border-2">
		<p class="ps-2"> ©2022 C.E Las Brisas. Derechos Reservados. </p>
		<ul class="d-flex justify-content-end list-unstyled pe-2">
			<li><a class="bi-facebook link-dark fs-3 m-1" href="#" title="Facebook"></a></li>
			<li><a class="bi-telegram link-dark fs-3 m-1" href="#" title="Telegram"></a></li>
		</ul>
	</footer>

	<!-- Script JS de Bootstrap -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>